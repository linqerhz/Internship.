const readline = require('readline');

// Create a readline interface
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

// Function to start the game
function startGame() {
  let playerScore = 0;
  let dealerScore = 0;
  let turn = "player";

  function gameLoop() {
    // Display current scores and turn
    console.log(`Player score: ${playerScore}`);
    console.log(`Dealer score: ${dealerScore}`);
    console.log(`Turn: ${turn}`);

    if (turn === "player") {
      // Player's turn
      const card = getRandomCard(); // Get a random card value
      playerScore += card; // Add the card value to player's score
      console.log(`Card is ${card}`);

      if (playerScore > 21) {
        console.log("Player lost!");
        askToPlayAgain();
        return;
      }
    } else {
      // Dealer's turn
      const card = getRandomCard(); // Get a random card value
      dealerScore += card; // Add the card value to dealer's score
      console.log(`Card is ${card}`);

      if (dealerScore > 21) {
        console.log("Dealer lost!");
        askToPlayAgain();
        return;
      }
    }

    if (turn === "player") {
      rl.question("More? ('no' to stop, any other phrase to continue):", (choice) => {
        if (choice.toLowerCase() === "no") {
          turn = "dealer"; // Switch turn to the dealer
        }
        gameLoop();
      });
    } else {
      // Artificial intelligence for the dealer's turn
      if (dealerScore < 17) {
        // Dealer takes another card if the score is less than 17
        console.log("Dealer takes another card.");
        sleep(3000).then(() => { // Pause for 3 seconds
          gameLoop();
        });
      } else {
        // Dealer stops if the score is 17 or higher
        console.log("Dealer stops.");
        sleep(3000).then(() => { // Pause for 3 seconds
          if(dealerScore < playerScore){
            console.log("Player wins");
            askToPlayAgain();
        return;
          }
          if(dealerScore > playerScore){
            console.log("Dealer wins.");
            askToPlayAgain();
        return;
          }
          gameLoop();
        });
      }
    }
  }

  gameLoop();
}

// Function to get a random card value from 1 to 10
function getRandomCard() {
  return Math.floor(Math.random() * 10) + 1;
}

// Function to pause the program for a specified amount of time
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// Function to display the game rules
function displayRules() {
  console.log("=== RULES ===");
  console.log("Each turn the player can take a card or stop.");
  console.log("If a player takes a card, they get from 1 to 10 points.");
  console.log("If the sum of the player's points is more than 21, they lose.");
  console.log("The same rules apply for the dealer.");
  console.log("================");
}

// Function to ask the user if they want to play again
function askToPlayAgain() {
  rl.question("Do you want to play again? (yes/no): ", (answer) => {
    if (answer.toLowerCase() === "yes") {
      startGame(); // Start a new game
    } else {
      rl.close(); // Close the program
    }
  });
}

// Function to handle the main menu and user choices
function main() {
  console.log("1 - Game");
  console.log("2 - Rules");
  console.log("3 - Exit");
  rl.question("> ", (choice) => {
    switch (choice) {
      case "1":
        startGame();
        break;
      case "2":
        displayRules();
        main();
        break;
      case "3":
        rl.close();
        break;
      default:
        console.log("Invalid choice. Please try again.");
        main();
    }
  });
}

// Call the main function to start the program
main();

// Close the readline interface when the program ends
rl.on('close', () => {
  console.log("Exiting the program.");
  process.exit(0);
});